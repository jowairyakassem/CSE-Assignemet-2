void hello();
int main() {
hello();
return 0;
}

