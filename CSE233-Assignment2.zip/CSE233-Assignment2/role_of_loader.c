#include <stdio.h>
int main() {
printf("This is JK's somple program.\n");
return 0;
}

